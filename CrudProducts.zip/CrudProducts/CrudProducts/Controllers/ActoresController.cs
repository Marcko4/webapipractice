﻿using AutoMapper;
using CrudProducts.DTOs;
using CrudProducts.Entities;
using Microsoft.AspNetCore.Mvc;

namespace CrudProducts.Controllers
{
    [ApiController]
    [Route ("api/actores")]
    public class ActoresController:ControllerBase
    {
        private readonly ApplicationDbContext context;
        private readonly IMapper mapper;

        public ActoresController(ApplicationDbContext context, IMapper mapper )
        {
            this.context = context;
            this.mapper = mapper;
        }
        [HttpPost] 
        
        public async Task<ActionResult>Post(ActorCreacionDTO actorCreacionDTO)
        {
            var actor = mapper.Map<Actor>(actorCreacionDTO);
            context.Add(actor);
            await context.SaveChangesAsync();
            return Ok();
        }
    }
}
