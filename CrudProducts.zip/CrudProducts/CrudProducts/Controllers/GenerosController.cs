﻿
using AutoMapper;
using CrudProducts.DTOs;
using CrudProducts.Entities;
using Microsoft.AspNetCore.Mvc;

namespace CrudProducts.Controllers
{

    [ApiController]
    [Route("api/generos")]
    public class GenerosController : ControllerBase
    {
        private readonly ApplicationDbContext context;
        private readonly IMapper mapper;

        public GenerosController(ApplicationDbContext context, IMapper mapper)
        {
            this.context = context;
            this.mapper = mapper;
        }

        [HttpPost]

        public async Task<ActionResult> Post(GeneroCreacionDTO generoCreacion)
        {
      
            var genero = mapper.Map<Genero>(generoCreacion);

            context.Add(genero);
            await context.SaveChangesAsync();
            return Ok();
        }

        [HttpPost("varios")]

        public async Task<ActionResult> Post(GeneroCreacionDTO [] generoCreacion)
        {
            var generos = mapper.Map<Genero[]>(generoCreacion);
            context.AddRange(generos);
            await context.SaveChangesAsync();
            return Ok();
                
        }

    }
}
