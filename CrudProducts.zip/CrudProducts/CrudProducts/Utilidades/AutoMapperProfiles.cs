﻿using AutoMapper;
using CrudProducts.DTOs;
using CrudProducts.Entities;


namespace CrudProducts.Utilidades
{
    public class AutoMapperProfiles : Profile
    {
        public AutoMapperProfiles()
        {
            CreateMap<GeneroCreacionDTO, Genero>();
            CreateMap<ActorCreacionDTO, Actor>();


        }
    }

}
